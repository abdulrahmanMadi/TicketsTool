export const Constants={
    API_Endpoint:{
        Get_Department:'/Departments/GetDepartments',
        Create_Department:'/Departments/CreateDepartment',
        Update_Department:'/Departments/UpdateDepartment',
        Delete_Department:'/Departments/DeleteDepartments',
        Products:'/products',
        Login:'/Authentication/Login',
    },
    Validition_Message:{
        Required:'This is required'
    }
}