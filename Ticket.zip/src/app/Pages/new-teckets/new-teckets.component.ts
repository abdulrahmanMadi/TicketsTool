import { Component } from '@angular/core';

@Component({
  selector: 'app-new-teckets',
  standalone: true,
  imports: [],
  templateUrl: './new-teckets.component.html',
  styleUrl: './new-teckets.component.scss'
})
export class NewTecketsComponent {

}
