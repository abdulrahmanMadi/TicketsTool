export const environment = {
    API_Url: 'https://localhost:7140/api',

};
